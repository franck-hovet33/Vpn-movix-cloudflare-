# Movix VPN v22

Version Android 5+ légère. Le mode 1.1.1.1 est un VPN DNS local vers Cloudflare 1.1.1.1. Le sélecteur WARP est affiché mais le véritable tunnel WARP Cloudflare n’est pas implémenté sur Android 5 dans cette version : il est signalé comme indisponible plutôt que simulé.

Fonctions : portée téléphone/Movix, historique détaillé, diagnostic VPN, widget 2x2 redimensionnable.
