package cash.movix.app;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class VpnHistory {
    private static final String PREF="vpn_history";
    private static final int MAX=60;
    private VpnHistory(){}
    public static void add(Context c,String event){
        String old=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("items","");
        String line=new SimpleDateFormat("dd/MM/yyyy — HH:mm:ss",Locale.FRANCE).format(new Date())+"\n"+event;
        String all=line+(old.length()>0?"\n\n"+old:"");
        String[] a=all.split("\\n\\n"); StringBuilder b=new StringBuilder();
        for(int i=0;i<a.length && i<MAX;i++){if(i>0)b.append("\n\n");b.append(a[i]);}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("items",b.toString()).apply();
    }
    public static String get(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("items","");}
}
