package cash.movix.app;

import android.content.Context;
import android.content.Intent;

public final class MovixVpnState {
    private static final String PREF = "vpn_state";
    private static final String ON = "on";
    private static final String MODE = "mode";
    private static final String SCOPE = "scope";
    private static final String ERROR = "error";
    private MovixVpnState() {}

    public static void set(Context c, boolean on) {
        set(c, on, getMode(c), getScope(c), null);
    }
    public static void set(Context c, boolean on, String mode, String scope, String error) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(ON, on)
                .putString(MODE, mode == null ? "1.1.1.1" : mode)
                .putString(SCOPE, scope == null ? "Téléphone" : scope)
                .putString(ERROR, error == null ? "" : error)
                .apply();
        String event;
        if (error != null && error.length() > 0) event = "Erreur VPN — " + error;
        else event = (on ? "VPN activé" : "VPN désactivé") + " — " + getMode(c) + " — " + getScope(c);
        VpnHistory.add(c, event);
        broadcast(c);
        MovixWidget.updateAll(c);
    }
    public static boolean isOn(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(ON, false); }
    public static String getMode(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(MODE, "1.1.1.1"); }
    public static String getScope(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(SCOPE, "Téléphone"); }
    public static String getLastError(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(ERROR, ""); }
    public static void setSelection(Context c, String mode, String scope) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(MODE, mode).putString(SCOPE, scope).apply();
        broadcast(c); MovixWidget.updateAll(c);
    }
    public static void recordError(Context c, String error) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(ON, false).putString(ERROR, error == null ? "Erreur inconnue" : error).apply();
        VpnHistory.add(c, "Erreur VPN — " + (error == null ? "Erreur inconnue" : error) + " — " + getMode(c) + " — " + getScope(c));
        broadcast(c); MovixWidget.updateAll(c);
    }
    private static void broadcast(Context c) {
        Intent i = new Intent("cash.movix.app.VPN_STATE_CHANGED");
        i.setPackage(c.getPackageName());
        c.sendBroadcast(i);
    }
}
