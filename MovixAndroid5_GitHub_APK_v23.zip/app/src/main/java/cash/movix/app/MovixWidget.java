package cash.movix.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;

public class MovixWidget extends AppWidgetProvider {
    private static final String TOGGLE="cash.movix.app.WIDGET_TOGGLE";
    private static final String MODE="cash.movix.app.WIDGET_MODE";
    private static final String OPEN="cash.movix.app.WIDGET_OPEN";
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,android.os.Bundle options){super.onAppWidgetOptionsChanged(c,m,id,options);update(c,m,id);}
    @Override public void onReceive(Context c,Intent i){
        super.onReceive(c,i);
        if(TOGGLE.equals(i.getAction())) toggle(c);
        else if(MODE.equals(i.getAction())) switchMode(c);
        else if(OPEN.equals(i.getAction())) openHub(c);
    }
    private void toggle(Context c){
        if(MovixVpnState.isOn(c)) c.startService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_STOP));
        else {Intent prep=android.net.VpnService.prepare(c);if(prep!=null){Intent open=new Intent(c,MainActivity.class).putExtra("request_vpn",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);c.startActivity(open);}else c.startService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_START));}
        updateAll(c);
    }
    private void switchMode(Context c){
        final AppWidgetManager manager=AppWidgetManager.getInstance(c); final int[] ids=manager.getAppWidgetIds(new android.content.ComponentName(c,MovixWidget.class));
        animateModeButton(c,manager,ids);
        String next="1.1.1.1".equals(MovixVpnState.getMode(c))?"WARP":"1.1.1.1";
        MovixVpnState.setSelection(c,next,MovixVpnState.getScope(c));
        if(MovixVpnState.isOn(c)){
            c.startService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_STOP));
            if("1.1.1.1".equals(next)) c.startService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_START));
            else MovixVpnState.recordError(c,"WARP sélectionné : tunnel WARP non disponible sur cette version Android 5.");
        }
        updateAll(c);
    }
    private void animateModeButton(final Context c, final AppWidgetManager m, final int[] ids){
        final int[] frames={R.drawable.widget_rotate_0,R.drawable.widget_rotate_1,R.drawable.widget_rotate_2,R.drawable.widget_rotate_3,R.drawable.widget_rotate_4,R.drawable.widget_rotate_5,R.drawable.widget_rotate_6,R.drawable.widget_rotate_7};
        final android.os.Handler h=new android.os.Handler();
        for(int i=0;i<frames.length;i++){ final int frame=i; h.postDelayed(new Runnable(){public void run(){for(int id:ids){update(c,m,id);android.os.Bundle o=m.getAppWidgetOptions(id);int w=o==null?110:o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,110);int hh=o==null?110:o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,110);RemoteViews v=new RemoteViews(c.getPackageName(),(w>=180&&hh>=180)?R.layout.widget_movix_expanded:R.layout.widget_movix);v.setImageViewResource(R.id.widget_mode_button,frames[frame]);m.updateAppWidget(id,v);}}},i*28); }
    }
    private void openHub(Context c){Intent i=new Intent(c,MainActivity.class).putExtra("open_hub",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);c.startActivity(i);}
    static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new android.content.ComponentName(c,MovixWidget.class));for(int id:ids)update(c,m,id);}
    private static void update(Context c,AppWidgetManager m,int id){
        boolean on=MovixVpnState.isOn(c); String mode=MovixVpnState.getMode(c); String scope=MovixVpnState.getScope(c);
        android.os.Bundle o=m.getAppWidgetOptions(id); int minW=o==null?110:o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,110); int minH=o==null?110:o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,110);
        int layout=(minW>=180 && minH>=180)?R.layout.widget_movix_expanded:R.layout.widget_movix;
        RemoteViews v=new RemoteViews(c.getPackageName(),layout);
        v.setTextViewText(R.id.widget_status,on?"ACTIF":"ÉTEINT");
        v.setTextViewText(R.id.widget_mode,mode);
        v.setTextViewText(R.id.widget_scope,scope);
        try{String hist=VpnHistory.get(c);String[] ev=hist.split("\n\n");v.setTextViewText(R.id.widget_event,ev.length>0&&ev[0].length()>0?ev[0]:"Aucun événement");}catch(Exception ignored){}
        v.setTextColor(R.id.widget_status,on?Color.rgb(120,225,135):Color.rgb(245,240,223));
        v.setTextViewText(R.id.widget_toggle,"●");
        v.setTextColor(R.id.widget_toggle,on?Color.rgb(120,225,135):Color.rgb(180,174,164));
        v.setInt(R.id.widget_toggle,"setGravity",on?android.view.Gravity.RIGHT|android.view.Gravity.CENTER_VERTICAL:android.view.Gravity.LEFT|android.view.Gravity.CENTER_VERTICAL);
        Intent t=new Intent(c,MovixWidget.class).setAction(TOGGLE);PendingIntent tp=PendingIntent.getBroadcast(c,id+1000,t,PendingIntent.FLAG_UPDATE_CURRENT);v.setOnClickPendingIntent(R.id.widget_toggle,tp);
        Intent mo=new Intent(c,MovixWidget.class).setAction(MODE);PendingIntent mp=PendingIntent.getBroadcast(c,id+2000,mo,PendingIntent.FLAG_UPDATE_CURRENT);v.setOnClickPendingIntent(R.id.widget_mode_button,mp);
        Intent op=new Intent(c,MovixWidget.class).setAction(OPEN);PendingIntent opi=PendingIntent.getBroadcast(c,id+3000,op,PendingIntent.FLAG_UPDATE_CURRENT);v.setOnClickPendingIntent(R.id.widget_open,opi);
        m.updateAppWidget(id,v);
    }
}
