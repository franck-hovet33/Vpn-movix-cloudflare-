package cash.movix.app;

import android.content.Context;
import android.os.Build;

import com.wireguard.crypto.KeyPair;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/** Small Cloudflare WARP registration/config client for old Android devices. */
public final class WarpClient {
    private static final String BASE = "https://api.cloudflareclient.com/v0a1922";
    private static final String CLIENT = "a-6.3-1922";
    private static final String UA = "okhttp/3.12.1";
    private static final String PREF = "warp_identity";
    private static final String ROOT_X1 =
            "-----BEGIN CERTIFICATE-----\n" +
"MIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw\n" +
"TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\n" +
"cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4\n" +
"WhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu\n" +
"ZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY\n" +
"MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc\n" +
"h77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+\n" +
"0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U\n" +
"A5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW\n" +
"T8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH\n" +
"B5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC\n" +
"B5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv\n" +
"KBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn\n" +
"OlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn\n" +
"jh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw\n" +
"qHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI\n" +
"rU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV\n" +
"HRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq\n" +
"hkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL\n" +
"ubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ\n" +
"3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK\n" +
"NFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5\n" +
"ORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur\n" +
"TkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC\n" +
"jNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc\n" +
"oyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq\n" +
"4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA\n" +
"mRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d\n" +
"emyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=\n" +
"-----END CERTIFICATE-----\n";

    private WarpClient() {}

    public static final class ConfigData {
        public String privateKey;
        public String addressV4;
        public String addressV6;
        public String peerPublicKey;
        public String endpoint;
    }

    public static ConfigData getOrCreate(Context context) throws Exception {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String privateKey = p.getString("private_key", null);
        String accountId = p.getString("account_id", null);
        String token = p.getString("token", null);
        KeyPair kp;
        if (privateKey == null || accountId == null || token == null) {
            kp = new KeyPair();
            privateKey = kp.getPrivateKey().toBase64();
            String publicKey = kp.getPublicKey().toBase64();
            String install = randomInstallId();
            String tos = isoNow();
            String body = "{\"key\":\"" + publicKey + "\",\"install_id\":\"" + install + "\",\"fcm_token\":\"\",\"tos\":\"" + tos + "\",\"model\":\"" + esc(Build.MODEL) + "\",\"serial_number\":\"" + install + "\",\"locale\":\"fr_FR\"}";
            String response = request("POST", BASE + "/reg", body, null);
            accountId = find(response, "\\\"id\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
            token = find(response, "\\\"token\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
            if (accountId == null || token == null) throw new Exception("Réponse d'inscription WARP invalide");
            p.edit().putString("private_key", privateKey).putString("account_id", accountId).putString("token", token).apply();
        }
        String auth = "Bearer " + token;
        String patch = request("PATCH", BASE + "/reg/" + accountId, "{\"warp_enabled\":true}", auth);
        String config = request("GET", BASE + "/reg/" + accountId, null, auth);
        ConfigData out = new ConfigData();
        out.privateKey = privateKey;
        out.addressV4 = find(config, "\\\"addresses\\\"\\s*:\\s*\\{[^}]*\\\"v4\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        out.addressV6 = find(config, "\\\"addresses\\\"\\s*:\\s*\\{[^}]*\\\"v4\\\"\\s*:\\s*\\\"[^\\\"]+\\\"[^}]*\\\"v6\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        out.peerPublicKey = find(config, "\\\"peers\\\"\\s*:\\s*\\[\\s*\\{[^}]*\\\"public_key\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        out.endpoint = find(config, "\\\"endpoint\\\"\\s*:\\s*\\{[^}]*\\\"v4\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        if (out.addressV4 == null || out.peerPublicKey == null || out.endpoint == null) throw new Exception("Configuration WARP incomplète");
        if (out.endpoint.endsWith(":0")) out.endpoint = out.endpoint.substring(0, out.endpoint.length()-2) + ":2408";
        return out;
    }

    private static String request(String method, String urlString, String body, String auth) throws Exception {
        HttpURLConnection raw=(HttpURLConnection)new URL(urlString).openConnection();
        if (!(raw instanceof HttpsURLConnection)) throw new Exception("HTTPS requis");
        HttpsURLConnection c=(HttpsURLConnection)raw;
        SSLSocketFactory sf=buildSocketFactory();
        if(sf!=null)c.setSSLSocketFactory(sf);
        c.setHostnameVerifier((hostname,session)-> HttpsURLConnection.getDefaultHostnameVerifier().verify(hostname,session));
        c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestMethod(method);c.setRequestProperty("User-Agent",UA);c.setRequestProperty("CF-Client-Version",CLIENT);c.setRequestProperty("Accept","application/json");
        if(auth!=null)c.setRequestProperty("Authorization",auth);
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");OutputStream o=c.getOutputStream();o.write(body.getBytes("UTF-8"));o.close();}
        int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();String text=read(in);c.disconnect();
        if(code<200||code>=300) throw new Exception("Cloudflare WARP HTTP "+code+(text.length()>0?" — "+text:""));
        return text;
    }

    private static SSLSocketFactory buildSocketFactory(){
        try{
            CertificateFactory cf=CertificateFactory.getInstance("X.509");
            Certificate root=cf.generateCertificate(new ByteArrayInputStream(ROOT_X1.getBytes("US-ASCII")));
            TrustManagerFactory system=TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            system.init((KeyStore)null);
            KeyStore ks=KeyStore.getInstance(KeyStore.getDefaultType());ks.load(null,null);ks.setCertificateEntry("isrg-x1",root);
            TrustManagerFactory extra=TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());extra.init(ks);
            X509TrustManager a=findX509(system.getTrustManagers()), b=findX509(extra.getTrustManagers());
            X509TrustManager combined=new X509TrustManager(){
                public X509Certificate[] getAcceptedIssuers(){X509Certificate[] x=a.getAcceptedIssuers(),y=b.getAcceptedIssuers();X509Certificate[] z=new X509Certificate[x.length+y.length];System.arraycopy(x,0,z,0,x.length);System.arraycopy(y,0,z,x.length,y.length);return z;}
                public void checkClientTrusted(X509Certificate[] c,String auth)throws java.security.cert.CertificateException{try{a.checkClientTrusted(c,auth);}catch(java.security.cert.CertificateException e){b.checkClientTrusted(c,auth);}}
                public void checkServerTrusted(X509Certificate[] c,String auth)throws java.security.cert.CertificateException{try{a.checkServerTrusted(c,auth);}catch(java.security.cert.CertificateException e){b.checkServerTrusted(c,auth);}}
            };
            SSLContext sc=SSLContext.getInstance("TLS");sc.init(null,new TrustManager[]{combined},new SecureRandom());return sc.getSocketFactory();
        }catch(Throwable e){return null;}
    }
    private static X509TrustManager findX509(TrustManager[] managers){
        for(TrustManager m:managers) if(m instanceof X509TrustManager) return (X509TrustManager)m;
        throw new IllegalStateException("X509 trust manager indisponible");
    }
    private static String read(InputStream in)throws Exception{if(in==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[2048];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return new String(b.toByteArray(),Charset.forName("UTF-8"));}
    private static String find(String text,String regex){if(text==null)return null;java.util.regex.Matcher m=java.util.regex.Pattern.compile(regex,java.util.regex.Pattern.DOTALL).matcher(text);return m.find()?m.group(1):null;}
    private static String randomInstallId(){String chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";SecureRandom r=new SecureRandom();StringBuilder b=new StringBuilder(22);for(int i=0;i<22;i++)b.append(chars.charAt(r.nextInt(chars.length())));return b.toString();}
    private static String isoNow(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private static String esc(String s){if(s==null)return "Android";return s.replace("\\","\\\\").replace("\"","\\\"");}
}
