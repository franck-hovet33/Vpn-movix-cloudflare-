package cash.movix.app;

import android.content.Context;
import android.content.Intent;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.InetNetwork;
import com.wireguard.config.Peer;

import java.net.InetAddress;

import static com.wireguard.android.backend.Tunnel.State.DOWN;
import static com.wireguard.android.backend.Tunnel.State.UP;

/** Cloudflare WARP over the embedded WireGuard userspace backend. */
public final class WarpTunnelController {
    private static final Object LOCK = new Object();
    private static Backend backend;
    private static Tunnel tunnel;
    private static boolean starting;
    private static String lastError = "";

    private WarpTunnelController() {}

    public static void start(final Context context, final String scope) {
        synchronized (LOCK) {
            if (starting) return;
            starting = true;
        }
        new Thread(() -> {
            try {
                Context app = context.getApplicationContext();
                ensureBackend(app);
                WarpClient.ConfigData data = WarpClient.getOrCreate(app);
                Config.Builder config = new Config.Builder();
                com.wireguard.config.Interface.Builder ib = new com.wireguard.config.Interface.Builder();
                ib.addAddress(InetNetwork.parse(data.addressV4 + "/32"));
                if (data.addressV6 != null && data.addressV6.length() > 0) {
                    try { ib.addAddress(InetNetwork.parse(data.addressV6 + "/128")); } catch (Exception ignored) {}
                }
                ib.addDnsServer(InetAddress.getByName("1.1.1.1"));
                if ("Movix uniquement".equals(scope)) ib.includeApplication(app.getPackageName());
                Peer.Builder pb = new Peer.Builder();
                pb.addAllowedIp(InetNetwork.parse("0.0.0.0/0"));
                try { pb.addAllowedIp(InetNetwork.parse("::/0")); } catch (Exception ignored) {}
                pb.setEndpoint(com.wireguard.config.InetEndpoint.parse(data.endpoint));
                pb.parsePublicKey(data.peerPublicKey);
                config.setInterface(ib.parsePrivateKey(data.privateKey).build());
                config.addPeer(pb.build());
                backend.setState(tunnel, UP, config.build());
                lastError = "";
                MovixVpnState.set(app, true, "WARP", scope, null);
            } catch (Throwable e) {
                lastError = safe(e);
                try { if (backend != null && tunnel != null) backend.setState(tunnel, DOWN, null); } catch (Throwable ignored) {}
                MovixVpnState.recordError(context.getApplicationContext(), "WARP : " + lastError);
            } finally {
                synchronized (LOCK) { starting = false; }
                MovixWidget.updateAll(context.getApplicationContext());
            }
        }, "Movix-WARP").start();
    }

    public static void stop(Context context) {
        Context app=context.getApplicationContext();
        new Thread(() -> {
            try {
                ensureBackend(app);
                if (backend != null && tunnel != null) backend.setState(tunnel, DOWN, null);
                MovixVpnState.set(app, false, "WARP", MovixVpnState.getScope(app), null);
            } catch (Throwable e) {
                MovixVpnState.recordError(app, "Arrêt WARP : " + safe(e));
            } finally { MovixWidget.updateAll(app); }
        }, "Movix-WARP-stop").start();
    }

    public static boolean isRunning(Context context) {
        synchronized (LOCK) {
            try { return backend != null && tunnel != null && backend.getState(tunnel) == UP; }
            catch (Throwable e) { return false; }
        }
    }

    public static String getLastError() { synchronized (LOCK) { return lastError; } }

    private static void ensureBackend(Context app) {
        synchronized (LOCK) {
            if (backend == null) backend = new GoBackend(app);
            if (tunnel == null) tunnel = new WarpTunnel();
        }
        try { app.startService(new Intent(app, GoBackend.VpnService.class)); } catch (Throwable ignored) {}
    }

    private static String safe(Throwable e) {
        String m=e.getMessage(); return m==null?e.getClass().getSimpleName():e.getClass().getSimpleName()+" — "+m;
    }

    private static final class WarpTunnel implements Tunnel {
        @Override public String getName() { return "Movix-WARP"; }
        @Override public void onStateChange(State newState) {
            if (newState == DOWN) {
                // The explicit controller updates the persisted state; this callback is intentionally lightweight.
            }
        }
    }
}
