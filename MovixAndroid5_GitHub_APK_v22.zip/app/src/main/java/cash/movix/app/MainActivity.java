package cash.movix.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.PopupWindow;
import android.widget.Toast;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://movix.cash";
    private static final String APP_VERSION = "2.7";
    private static final int RED = Color.rgb(217, 70, 70);
    private static final int BG = Color.rgb(5, 5, 5);
    private static final int CARD = Color.rgb(21, 21, 21);
    private static final int TEXT = Color.rgb(245, 240, 223);
    private static final int MUTED = Color.rgb(180, 174, 164);

    private FrameLayout root;
    private WebView webView;
    private View loadingView;
    private View errorView;
    private TextView loadingPercent;
    private TextView loadingStatus;
    private ProgressBar loadingProgress;
    private TextView errorTitle;
    private TextView errorText;
    private TextView errorAdvice;
    private String lastUrl = DEFAULT_URL;
    private static final String URL_HISTORY_KEY = "url_history";
    private static final int MAX_URL_HISTORY = 8;
    private String lastErrorType = "server";
    private boolean loading = false;
    private boolean directPageMode = false;
    private Button vpnButton;
    private Dialog vpnDialog;
    private TextView vpnStateView, vpnModeView, vpnScopeView, vpnErrorView;
    private ToggleSwitch vpnSwitch;
    private TextView vpn1111Choice, vpnWarpChoice, vpnPhoneChoice, vpnAppChoice;
    private android.content.BroadcastReceiver vpnReceiver;
    private PopupWindow urlHistoryPopup;
    private long generation = 0L;
    private final Handler handler = new Handler();
    private Runnable timeoutTask;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);
        lastUrl = getPreferences(MODE_PRIVATE).getString("url", DEFAULT_URL);
        if (!getPreferences(MODE_PRIVATE).contains(URL_HISTORY_KEY)) saveUrlHistory(lastUrl);
        buildUi();
        createWebView();
        registerVpnReceiver();
        startLoad(lastUrl);
        if (getIntent().getBooleanExtra("request_vpn", false)) handler.postDelayed(this::requestVpnFromActivity, 250);
        if (getIntent().getBooleanExtra("open_hub", false)) handler.postDelayed(this::showAppHub, 250);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        loadingView = buildLoadingView();
        errorView = buildErrorView();
        root.addView(loadingView, fullParams());
        root.addView(errorView, fullParams());
        errorView.setVisibility(View.GONE);
    }

    private FrameLayout.LayoutParams fullParams() { return new FrameLayout.LayoutParams(-1, -1); }

    private View buildLoadingView() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(196, 48, 48));
        ImageView art = new ImageView(this);
        art.setImageResource(cash.movix.app.R.drawable.movix_splash_red);
        art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(art, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout loadingCard = new LinearLayout(this);
        loadingCard.setOrientation(LinearLayout.VERTICAL);
        loadingCard.setPadding(dp(18), dp(14), dp(18), dp(14));
        loadingCard.setBackground(round(Color.rgb(7,7,7), Color.WHITE, 14));
        loadingCard.setGravity(Gravity.CENTER_HORIZONTAL);
        loadingCard.setElevation(dp(5));
        loadingPercent = text("0 %", 27, TEXT, true);
        loadingStatus = text("Vérification de la connexion…", 13, MUTED, false);
        loadingStatus.setGravity(Gravity.CENTER);
        TextView label = text("chargement", 18, TEXT, true);
        loadingCard.addView(label, wrap());
        loadingCard.addView(loadingPercent, wrap());
        LinearLayout.LayoutParams slp=wrap(); slp.topMargin=dp(2); loadingCard.addView(loadingStatus,slp);
        loadingProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingProgress.setMax(100); loadingProgress.setProgress(0);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(8)); pp.topMargin=dp(10); loadingCard.addView(loadingProgress,pp);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2,Gravity.LEFT|Gravity.BOTTOM);
        cp.setMargins(dp(18),0,dp(18),dp(22)); frame.addView(loadingCard,cp);
        return frame;
    }

    private View buildErrorView() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(7, 7, 7));
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER);
        outer.setPadding(dp(22), dp(22), dp(22), dp(22));

        LinearLayout card = cardLayout();
        FrameLayout cardFrame = new FrameLayout(this);
        cardFrame.setBackground(round(CARD, Color.rgb(41,41,41), 14));
        cardFrame.setPadding(dp(24), dp(24), dp(24), dp(24));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView icon = text("!", 28, Color.rgb(232,106,106), true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(Color.rgb(42,18,18), Color.rgb(140,56,56), 24));
        content.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        errorTitle = text("Un problème est survenu", 24, TEXT, true);
        errorTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = wrap(); tlp.bottomMargin = dp(10); tlp.topMargin = dp(10);
        content.addView(errorTitle, tlp);
        errorText = text("", 15, Color.LTGRAY, false); errorText.setGravity(Gravity.CENTER); content.addView(errorText, wrap());
        errorAdvice = text("", 14, Color.rgb(204,204,204), false); errorAdvice.setPadding(dp(12),dp(12),dp(12),dp(12)); errorAdvice.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); errorAdvice.setBackground(round(Color.rgb(12,12,12), Color.rgb(36,36,36), 8));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2); alp.topMargin=dp(12); content.addView(errorAdvice, alp);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(16),0,0);
        Button retry = button("Réessayer", true); Button url = button("URL", false); Button vpn = button("VPN", false);
        buttons.addView(retry, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, dp(50), 1); ulp.leftMargin=dp(7); buttons.addView(url, ulp);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(0, dp(50), 1); vlp.leftMargin=dp(7); buttons.addView(vpn, vlp);
        content.addView(buttons);
        cardFrame.addView(content, fullParams());

        Button more = new Button(this);
        more.setText("⋮"); more.setTextSize(27); more.setTextColor(TEXT); more.setBackgroundColor(Color.TRANSPARENT); more.setPadding(0,0,0,0);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(dp(42),dp(42),Gravity.RIGHT|Gravity.TOP); mlp.setMargins(0,dp(5),dp(7),0); cardFrame.addView(more,mlp);
        more.setOnClickListener(v -> showDiagnosticMenu());

        outer.addView(cardFrame, new LinearLayout.LayoutParams(-1, -2));
        frame.addView(outer, fullParams());
        retry.setOnClickListener(v -> {
            errorView.setVisibility(View.GONE);
            startLoad(lastUrl);
        });
        url.setOnClickListener(v -> showUrlDialog(true));
        vpn.setOnClickListener(v -> showVpnDialog());
        return frame;
    }

    private LinearLayout cardLayout(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private void createWebView() {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkLoads(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        webView.setVisibility(View.GONE);
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView v,int p){
                if(!loading) return;
                setLoadingProgress(Math.max(3,Math.min(96,p)), p < 25 ? "Connexion au serveur…" : "Chargement de Movix…");
            }
        });
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){ return handleUrl(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){ return req==null || req.getUrl()==null ? false : handleUrl(req.getUrl().toString()); }
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap b){ if(loading) setLoadingProgress(Math.max(5,v.getProgress()),"Connexion au serveur…"); }
            @Override public void onPageFinished(WebView v,String url){ if(!loading) return; if(url!=null && url.length()>0) lastUrl=url; showContent(); }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError e){ if(Build.VERSION.SDK_INT>=21 && req!=null && req.isForMainFrame() && loading) fail("server"); }
            @Override public void onReceivedError(WebView v,int code,String desc,String failingUrl){ if(!loading)return; String current=v.getUrl(); if(failingUrl==null || current==null || failingUrl.equals(current)) fail("server"); }
            @Override public void onReceivedHttpError(WebView v,WebResourceRequest req,WebResourceResponse res){ if(Build.VERSION.SDK_INT>=21 && req!=null && req.isForMainFrame() && loading && res!=null && res.getStatusCode()>=400) fail("server"); }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){ h.cancel(); if(loading) fail("ssl"); }
        });
        root.addView(webView, fullParams());
    }

    private boolean handleUrl(String url){
        if(url==null) return false;
        if(url.startsWith("http://") || url.startsWith("https://")) return false;
        try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception ignored){}
        return true;
    }

    private void setLoadingProgress(int percent,String status){
        int p=Math.max(0,Math.min(100,percent));
        if(loadingPercent!=null) loadingPercent.setText(p+" %");
        if(loadingStatus!=null) loadingStatus.setText(status==null?"":status);
        if(loadingProgress!=null) loadingProgress.setProgress(p);
    }

    private void startLoad(String url){
        if(url==null || !(url.startsWith("http://")||url.startsWith("https://"))){ fail("badurl"); return; }
        lastUrl=url; getPreferences(MODE_PRIVATE).edit().putString("url",url).apply();
        final long g=++generation;
        loading=true;
        errorView.setVisibility(View.GONE); webView.setVisibility(View.GONE); loadingView.setVisibility(View.VISIBLE);
        setLoadingProgress(0,"Vérification de la connexion…");
        if(timeoutTask!=null) handler.removeCallbacks(timeoutTask);
        timeoutTask=()->{ if(loading && generation==g) fail("slow"); };
        handler.postDelayed(timeoutTask,25000);
        if(!hasInternet()){
            handler.postDelayed(()->{if(loading&&generation==g) fail("offline");},350);
            return;
        }
        try{
            webView.stopLoading();
            webView.clearFocus();
            webView.setVisibility(View.VISIBLE);
            webView.requestFocus(View.FOCUS_DOWN);
            final String target = url;
            handler.post(() -> {
                if (!loading || generation != g || isFinishing()) return;
                try {
                    webView.loadUrl(target);
                } catch (Throwable e) {
                    if (generation == g) fail("server");
                }
            });
        }catch(Throwable e){ if(generation==g) fail("server"); }
    }


    private void showLoadingThenLoad(){
        final String target = lastUrl;
        errorView.setVisibility(View.GONE);
        loadingView.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);
        setLoadingProgress(0,"Préparation du chargement…");
        if (timeoutTask != null) handler.removeCallbacks(timeoutTask);
        handler.postDelayed(() -> {
            if (isFinishing()) return;
            startLoad(target);
        }, 80);
    }


    private void openInBrowser(){
        final String target=lastUrl;
        if(target==null || !(target.startsWith("http://") || target.startsWith("https://"))){
            Toast.makeText(this,"Adresse invalide",Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(target));
            startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"Aucun navigateur disponible",Toast.LENGTH_SHORT).show();
        }
    }

    private void openPageDirectly(){
        final String target=lastUrl;
        if(target==null || !(target.startsWith("http://") || target.startsWith("https://"))){ fail("badurl"); return; }
        loading=false;
        directPageMode=true;
        generation++;
        if(timeoutTask!=null){ handler.removeCallbacks(timeoutTask); timeoutTask=null; }
        loadingView.setVisibility(View.GONE);
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        webView.bringToFront();
        webView.requestFocus(View.FOCUS_DOWN);
        try{
            webView.stopLoading();
            webView.loadUrl(target);
        }catch(Throwable ignored){}
    }

    private String errorTypeLabel(String type){
        if(type==null) return "inconnu";
        if("offline".equals(type)) return "connexion Internet absente";
        if("slow".equals(type)) return "délai de chargement dépassé";
        if("ssl".equals(type)) return "erreur HTTPS / TLS";
        if("badurl".equals(type)) return "adresse invalide";
        if("server".equals(type)) return "échec du chargement WebView / serveur";
        return type;
    }

    private void showContent(){
        if(!loading) return;
        loading=false;
        if(timeoutTask!=null) handler.removeCallbacks(timeoutTask);
        loadingView.setVisibility(View.GONE); errorView.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); webView.bringToFront(); webView.requestFocus(View.FOCUS_DOWN);
    }

    private void fail(String type){
        if(!loading && !"badurl".equals(type)) return;
        loading=false; generation++;
        if(timeoutTask!=null) handler.removeCallbacks(timeoutTask);
        lastErrorType=type;
        webView.setVisibility(View.GONE); loadingView.setVisibility(View.GONE); errorView.setVisibility(View.VISIBLE);
        if("offline".equals(type)){ setError("Aucune connexion Internet","Le téléphone ne semble pas avoir accès à Internet.","Vérifiez le Wi‑Fi ou les données mobiles, puis appuyez sur « Réessayer ». "); }
        else if("slow".equals(type)){ setError("Connexion trop lente","Le chargement n'a pas terminé dans le délai prévu.","Le serveur ou la connexion est peut-être lent. Vous pouvez réessayer ou lancer le diagnostic."); }
        else if("ssl".equals(type)){ setError("Connexion sécurisée impossible","Le certificat HTTPS n'a pas pu être vérifié par Android.","Cela peut venir d'un certificat, de la date du téléphone ou d'une compatibilité TLS ancienne."); }
        else if("badurl".equals(type)){ setError("Adresse incorrecte","L'adresse configurée n'est pas valide.","Utilisez une adresse commençant par http:// ou https://."); }
        else { setError("Movix est inaccessible","La page n'a pas pu être chargée correctement dans le WebView.","Le diagnostic permet de distinguer un problème réseau, serveur ou de compatibilité WebView."); }
    }

    private void setError(String title,String text,String advice){ errorTitle.setText(title); errorText.setText(text); errorAdvice.setText(advice); }

    private boolean hasInternet(){ ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); NetworkInfo n=cm.getActiveNetworkInfo(); return n!=null && n.isConnected(); }

    private void registerVpnReceiver(){
        vpnReceiver=new android.content.BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){ if("cash.movix.app.VPN_STATE_CHANGED".equals(i.getAction())){ updateVpnDialog(); } }};
        android.content.IntentFilter f=new android.content.IntentFilter("cash.movix.app.VPN_STATE_CHANGED"); registerReceiver(vpnReceiver,f);
    }

    private void requestVpnFromActivity(){
        Intent prep=android.net.VpnService.prepare(this);
        if(prep!=null){try{startActivityForResult(prep,501);}catch(Exception e){VpnHistory.add(this,"Erreur — autorisation VPN impossible : "+e.getClass().getSimpleName());Toast.makeText(this,"Autorisation VPN impossible",Toast.LENGTH_SHORT).show();}}
        else startDnsVpn();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==501){if(resultCode==RESULT_OK)startDnsVpn();else{VpnHistory.add(this,"Erreur — autorisation VPN refusée");Toast.makeText(this,"VPN non autorisé",Toast.LENGTH_SHORT).show();updateVpnDialog();}}}
    private void startDnsVpn(){
        if(!"1.1.1.1".equals(MovixVpnState.getMode(this))){VpnHistory.add(this,"Erreur — WARP sélectionné mais non disponible sur Android 5");Toast.makeText(this,"WARP n'est pas disponible sur cette version",Toast.LENGTH_LONG).show();updateVpnDialog();return;}
        try{startService(new Intent(this,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_START));VpnHistory.add(this,"Demande de connexion — "+MovixVpnState.getMode(this)+" — "+MovixVpnState.getScope(this));updateVpnDialog();}catch(Exception e){MovixVpnState.recordError(this,"Impossible de démarrer le VPN : "+e.getClass().getSimpleName());}
    }
    private void stopDnsVpn(){try{startService(new Intent(this,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_STOP));}catch(Exception e){VpnHistory.add(this,"Erreur — arrêt VPN : "+e.getClass().getSimpleName());}}

    private TextView vpnLine(String s){TextView t=text(s,14,Color.LTGRAY,false);t.setPadding(0,dp(5),0,dp(5));return t;}
    private TextView modeChoice(String s, boolean selected){TextView t=text((selected?"●  ":"○  ")+s,14,selected?TEXT:MUTED,true);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(12),0,dp(12),0);t.setBackground(round(selected?Color.rgb(45,18,18):Color.rgb(25,25,25),selected?RED:Color.rgb(55,55,55),10));return t;}

    private void showVpnDialog(){
        if(vpnDialog!=null && vpnDialog.isShowing()){updateVpnDialog();return;}
        final Dialog d=dialog(); vpnDialog=d; LinearLayout box=dialogBox();
        TextView title=text("VPN / DNS",21,TEXT,true);box.addView(title,wrap());
        vpnStateView=text("",16,TEXT,true);LinearLayout.LayoutParams st=wrap();st.topMargin=dp(8);box.addView(vpnStateView,st);
        vpnModeView=text("",14,MUTED,true);box.addView(vpnModeView,wrap());
        vpnScopeView=text("",14,MUTED,false);box.addView(vpnScopeView,wrap());
        vpnErrorView=text("",12,Color.rgb(235,135,135),false);vpnErrorView.setBackground(round(Color.rgb(38,14,14),Color.rgb(110,45,45),9));vpnErrorView.setPadding(dp(10),dp(8),dp(10),dp(8));LinearLayout.LayoutParams ep=wrap();ep.topMargin=dp(8);box.addView(vpnErrorView,ep);

        LinearLayout switchRow=new LinearLayout(this);switchRow.setGravity(Gravity.CENTER_VERTICAL);switchRow.setPadding(0,dp(12),0,dp(4));
        TextView swLabel=text("VPN",15,TEXT,true);switchRow.addView(swLabel,new LinearLayout.LayoutParams(0,dp(42),1));
        vpnSwitch=new ToggleSwitch(this); vpnSwitch.setChecked(MovixVpnState.isOn(this)); switchRow.addView(vpnSwitch,new LinearLayout.LayoutParams(dp(68),dp(34)));box.addView(switchRow);
        vpnSwitch.setOnClickListener(v->{if(MovixVpnState.isOn(this))stopDnsVpn();else requestVpnFromActivity();});

        TextView mh=text("Mode",13,MUTED,true);LinearLayout.LayoutParams mhp=wrap();mhp.topMargin=dp(8);box.addView(mh,mhp);
        LinearLayout modes=new LinearLayout(this);modes.setOrientation(LinearLayout.HORIZONTAL);
        vpn1111Choice=modeChoice("1.1.1.1", "1.1.1.1".equals(MovixVpnState.getMode(this)));TextView m1111=vpn1111Choice; vpnWarpChoice=modeChoice("WARP", "WARP".equals(MovixVpnState.getMode(this)));TextView mwarp=vpnWarpChoice;
        modes.addView(m1111,new LinearLayout.LayoutParams(0,dp(44),1));LinearLayout.LayoutParams mwp=new LinearLayout.LayoutParams(0,dp(44),1);mwp.leftMargin=dp(8);modes.addView(mwarp,mwp);box.addView(modes);
        View.OnClickListener modeClick=v->{String mode=v==m1111?"1.1.1.1":"WARP";if(MovixVpnState.isOn(this)){stopDnsVpn();}MovixVpnState.setSelection(this,mode,MovixVpnState.getScope(this));if("WARP".equals(mode))VpnHistory.add(this,"Mode WARP sélectionné — tunnel WARP non disponible sur Android 5");updateVpnDialog();};m1111.setOnClickListener(modeClick);mwarp.setOnClickListener(modeClick);

        TextView sh=text("Utilisation",13,MUTED,true);LinearLayout.LayoutParams shp=wrap();shp.topMargin=dp(10);box.addView(sh,shp);
        final TextView scopePhone=modeChoice("Tout le téléphone", "Téléphone".equals(MovixVpnState.getScope(this)));
        final TextView scopeApp=modeChoice("Movix uniquement", "Movix uniquement".equals(MovixVpnState.getScope(this))); vpnPhoneChoice=scopePhone; vpnAppChoice=scopeApp;
        box.addView(scopePhone,new LinearLayout.LayoutParams(-1,dp(44)));LinearLayout.LayoutParams sap=new LinearLayout.LayoutParams(-1,dp(44));sap.topMargin=dp(7);box.addView(scopeApp,sap);
        View.OnClickListener scopeClick=v->{String scope=v==scopePhone?"Téléphone":"Movix uniquement";MovixVpnState.setSelection(this,MovixVpnState.getMode(this),scope);updateVpnDialog();};scopePhone.setOnClickListener(scopeClick);scopeApp.setOnClickListener(scopeClick);
        Button hist=button("Historique",false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(46));hp.topMargin=dp(10);box.addView(hist,hp);hist.setOnClickListener(v->showVpnHistoryDialog());
        Button close=button("Fermer",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(8);box.addView(close,cp);close.setOnClickListener(v->d.dismiss());
        d.setOnDismissListener(x->{vpnDialog=null;vpnStateView=null;vpnModeView=null;vpnScopeView=null;vpnErrorView=null;vpnSwitch=null;vpn1111Choice=null;vpnWarpChoice=null;vpnPhoneChoice=null;vpnAppChoice=null;});
        d.setContentView(box);d.show();sizeDialog(d,92,WindowManager.LayoutParams.WRAP_CONTENT);updateVpnDialog();
    }

    private void updateVpnDialog(){
        if(vpnDialog==null||!vpnDialog.isShowing())return;
        boolean on=MovixVpnState.isOn(this);String mode=MovixVpnState.getMode(this),scope=MovixVpnState.getScope(this),err=MovixVpnState.getLastError(this);
        if(vpnStateView!=null)vpnStateView.setText(on?"●  CONNECTÉ":"●  DÉCONNECTÉ");
        if(vpnStateView!=null)vpnStateView.setTextColor(on?Color.rgb(110,220,130):Color.rgb(220,110,110));
        if(vpnModeView!=null)vpnModeView.setText("Mode : "+mode);
        if(vpnScopeView!=null)vpnScopeView.setText("Portée : "+scope);
        if(vpnErrorView!=null){vpnErrorView.setVisibility(err.length()>0?View.VISIBLE:View.GONE);vpnErrorView.setText(err.length()>0?"Dernière erreur : "+err:"");}
        if(vpnSwitch!=null) vpnSwitch.setChecked(on);
        if(vpn1111Choice!=null){vpn1111Choice.setText(("1.1.1.1".equals(mode)?"●  ":"○  ")+"1.1.1.1");vpn1111Choice.setTextColor("1.1.1.1".equals(mode)?TEXT:MUTED);vpn1111Choice.setBackground(round("1.1.1.1".equals(mode)?Color.rgb(45,18,18):Color.rgb(25,25,25),"1.1.1.1".equals(mode)?RED:Color.rgb(55,55,55),10));}
        if(vpnWarpChoice!=null){vpnWarpChoice.setText(("WARP".equals(mode)?"●  ":"○  ")+"WARP");vpnWarpChoice.setTextColor("WARP".equals(mode)?TEXT:MUTED);vpnWarpChoice.setBackground(round("WARP".equals(mode)?Color.rgb(45,18,18):Color.rgb(25,25,25),"WARP".equals(mode)?RED:Color.rgb(55,55,55),10));}
        if(vpnPhoneChoice!=null){vpnPhoneChoice.setText(("Téléphone".equals(scope)?"●  ":"○  ")+"Tout le téléphone");vpnPhoneChoice.setTextColor("Téléphone".equals(scope)?TEXT:MUTED);}
        if(vpnAppChoice!=null){vpnAppChoice.setText(("Movix uniquement".equals(scope)?"●  ":"○  ")+"Movix uniquement");vpnAppChoice.setTextColor("Movix uniquement".equals(scope)?TEXT:MUTED);}
    }

    private void showVpnHistoryDialog(){
        final Dialog d=dialog();LinearLayout box=dialogBox();TextView title=text("Historique VPN",20,TEXT,true);box.addView(title,wrap());
        FrameLayout head=new FrameLayout(this); TextView sub=text("Heure, événement, mode et portée",12,MUTED,false);head.addView(sub,new FrameLayout.LayoutParams(-1,dp(32)));CopyIcon copy=new CopyIcon(this);head.addView(copy,new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.TOP));box.addView(head,new LinearLayout.LayoutParams(-1,dp(40)));
        ScrollView sv=new ScrollView(this);TextView body=text(VpnHistory.get(this).length()==0?"Aucun événement enregistré.":VpnHistory.get(this),13,Color.LTGRAY,false);body.setTextIsSelectable(true);body.setSingleLine(false);body.setHorizontallyScrolling(false);body.setPadding(0,dp(6),0,dp(8));sv.addView(body);box.addView(sv,new LinearLayout.LayoutParams(-1,0,1f));
        copy.setOnClickListener(v->{String report=VpnHistory.get(this);ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Historique VPN",report));copy.setCopied(true);handler.postDelayed(()->copy.setCopied(false),900);});
        Button close=button("Fermer",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(8);box.addView(close,cp);close.setOnClickListener(v->d.dismiss());d.setContentView(box);d.show();sizeDialog(d,92,Math.min((int)(getResources().getDisplayMetrics().heightPixels*.82f),dp(620)));
    }

    private void showAppHub(){
        final Dialog d=dialog();LinearLayout box=dialogBox();TextView title=text("Movix",24,TEXT,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));TextView sub=text("Accès rapide",13,MUTED,false);sub.setGravity(Gravity.CENTER);box.addView(sub,wrap());
        String[] labels={"Paramètres","URL","VPN","Historique","Diagnostic"};
        for(int i=0;i<labels.length;i++){final String label=labels[i];Button b=button(label,i==2);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50));bp.topMargin=dp(i==0?16:10);box.addView(b,bp);b.setOnClickListener(v->{d.dismiss();if("VPN".equals(label))showVpnDialog();else if("URL".equals(label))showUrlDialog(false);else if("Historique".equals(label))showVpnHistoryDialog();else if("Diagnostic".equals(label))runDiagnosticDialog();else Toast.makeText(this,"Paramètres disponibles prochainement",Toast.LENGTH_SHORT).show();});}
        Button close=button("Fermer",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(10);box.addView(close,cp);close.setOnClickListener(v->d.dismiss());d.setContentView(box);d.show();sizeDialog(d,88,WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void showUrlDialog(boolean fromError){
        final Dialog d=dialog();
        LinearLayout box=dialogBox();
        TextView title=text("Adresse",21,TEXT,true); box.addView(title,wrap());
        TextView sub=text("Adresse utilisée par l'application",14,MUTED,false);
        LinearLayout.LayoutParams sl=wrap(); sl.topMargin=dp(6); box.addView(sub,sl);

        android.widget.EditText input=new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(lastUrl);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setHint("https://movix.cash");
        input.setPadding(dp(12),dp(10),dp(12),dp(10));
        input.setBackground(round(Color.rgb(11,11,11),Color.rgb(68,68,68),8));
        LinearLayout.LayoutParams il=new LinearLayout.LayoutParams(-1,dp(50));
        il.topMargin=dp(14); box.addView(input,il);

        final java.util.ArrayList<String> historyItems=new java.util.ArrayList<>();
        Runnable closeHistoryPopup=() -> { if(urlHistoryPopup!=null){ urlHistoryPopup.dismiss(); urlHistoryPopup=null; } };

        Runnable refreshHistory=() -> {
            closeHistoryPopup.run();
            if(input.getText().toString().trim().length()>0) return;
            String raw=getPreferences(MODE_PRIVATE).getString(URL_HISTORY_KEY,"");
            if(raw.length()==0) return;
            historyItems.clear();
            for(String u:raw.split("\\n")){ if(u!=null && u.trim().length()>0) historyItems.add(u.trim()); }
            if(historyItems.isEmpty()) return;
            LinearLayout list=new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(8),dp(8),dp(8),dp(8));
            list.setBackground(round(CARD,Color.rgb(58,58,58),14));
            int rowH=dp(44), maxH=Math.min(dp(240),Math.max(rowH+dp(16),historyItems.size()*rowH+dp(16)));
            ScrollView sv=new ScrollView(this);
            sv.setFillViewport(true);
            sv.setBackground(round(CARD,Color.rgb(58,58,58),14));
            for(String u:historyItems){
                TextView item=text(u,13,TEXT,false);
                item.setGravity(Gravity.CENTER_VERTICAL); item.setSingleLine(true);
                item.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                item.setPadding(dp(10),0,dp(10),0);
                item.setBackground(round(Color.rgb(29,29,29),0,8));
                LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,rowH); ip.bottomMargin=dp(6); list.addView(item,ip);
                item.setOnClickListener(v->{ input.setText(u); input.setSelection(input.length()); closeHistoryPopup.run(); input.requestFocus(); });
            }
            sv.addView(list,new ScrollView.LayoutParams(-1,-2));
            urlHistoryPopup=new PopupWindow(sv,Math.max(dp(280),input.getWidth()),maxH,true);
            urlHistoryPopup.setBackgroundDrawable(round(CARD,Color.rgb(58,58,58),14));
            urlHistoryPopup.setOutsideTouchable(true);
            urlHistoryPopup.setFocusable(false);
            urlHistoryPopup.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
            urlHistoryPopup.setClippingEnabled(true);
            int[] loc=new int[2]; input.getLocationOnScreen(loc);
            int screenH=getResources().getDisplayMetrics().heightPixels;
            int desiredY=loc[1]-maxH-dp(8);
            int topLimit=getWindow().getDecorView().getTop()+dp(8);
            int y=Math.max(topLimit,desiredY);
            int availableAbove=Math.max(dp(80),loc[1]-topLimit-dp(8));
            int finalH=Math.min(maxH,availableAbove);
            if(finalH<dp(70)){ y=loc[1]+input.getHeight()+dp(8); finalH=Math.min(maxH,screenH-y-dp(12)); }
            urlHistoryPopup.setHeight(Math.max(dp(70),finalH));
            urlHistoryPopup.showAtLocation(input,Gravity.TOP|Gravity.LEFT,loc[0],y);
        };

        TextView msg=text("",13,Color.LTGRAY,false);
        LinearLayout.LayoutParams ml=wrap(); ml.topMargin=dp(7); box.addView(msg,ml);

        LinearLayout bs=new LinearLayout(this); bs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bl=new LinearLayout.LayoutParams(-1,dp(50)); bl.topMargin=dp(14); box.addView(bs,bl);
        Button cancel=button("Retour",false), save=button("Enregistrer",true);
        bs.addView(cancel,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams sav=new LinearLayout.LayoutParams(0,-1,1); sav.leftMargin=dp(10); bs.addView(save,sav);

        input.setOnFocusChangeListener((v,hasFocus) -> { if(hasFocus && input.getText().toString().trim().length()==0) handler.postDelayed(refreshHistory,80); else if(!hasFocus && urlHistoryPopup!=null) closeHistoryPopup.run(); });
        input.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ if(s.toString().trim().length()==0) handler.postDelayed(refreshHistory,40); else closeHistoryPopup.run(); msg.setText(""); }
            public void afterTextChanged(android.text.Editable e){}
        });

        View.OnClickListener saveAction=v->{
            String u=input.getText().toString().trim().replaceAll("/+$","");
            if(!u.matches("(?i)^https?://\\S+$")){ msg.setText("Adresse invalide."); return; }
            lastUrl=u;
            saveUrlHistory(u);
            getPreferences(MODE_PRIVATE).edit().putString("url",u).apply();
            d.dismiss();
            startLoad(u);
        };
        save.setOnClickListener(saveAction);
        input.setOnEditorActionListener((v,actionId,event) -> {
            boolean enter=actionId==android.view.inputmethod.EditorInfo.IME_ACTION_DONE || (event!=null && event.getKeyCode()==android.view.KeyEvent.KEYCODE_ENTER && event.getAction()==android.view.KeyEvent.ACTION_DOWN);
            if(enter){ saveAction.onClick(v); return true; }
            return false;
        });
        cancel.setOnClickListener(v->d.dismiss());

        d.setContentView(box); d.show(); sizeDialog(d,92,WindowManager.LayoutParams.WRAP_CONTENT);
        input.requestFocus();
        input.postDelayed(() -> { if(input.getText().toString().trim().length()==0) refreshHistory.run(); },120);
    }

    private void saveUrlHistory(String url){
        String clean=url==null?"":url.trim();
        if(clean.length()==0) return;
        String raw=getPreferences(MODE_PRIVATE).getString(URL_HISTORY_KEY,"");
        java.util.ArrayList<String> list=new java.util.ArrayList<>();
        if(raw.length()>0){
            for(String item:raw.split("\\n")){ if(item!=null && item.trim().length()>0 && !item.trim().equalsIgnoreCase(clean)) list.add(item.trim()); }
        }
        list.add(0,clean);
        while(list.size()>MAX_URL_HISTORY) list.remove(list.size()-1);
        StringBuilder out=new StringBuilder();
        for(String item:list){ if(out.length()>0) out.append('\n'); out.append(item); }
        getPreferences(MODE_PRIVATE).edit().putString(URL_HISTORY_KEY,out.toString()).apply();
    }

    private void showDiagnosticMenu(){
        final Dialog d=dialog(); LinearLayout box=dialogBox();
        TextView title=text("Options",21,TEXT,true);box.addView(title,wrap());
        TextView sub=text("Choisissez une action",14,MUTED,false);LinearLayout.LayoutParams sp=wrap();sp.topMargin=dp(6);box.addView(sub,sp);
        Button view=button("Voir la page",true), diag=button("Trouver le problème",false), browser=button("Ouvrir dans le navigateur",false);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(50));vp.topMargin=dp(16);box.addView(view,vp);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,dp(50));dp1.topMargin=dp(10);box.addView(diag,dp1);LinearLayout.LayoutParams bp2=new LinearLayout.LayoutParams(-1,dp(50));bp2.topMargin=dp(10);box.addView(browser,bp2);
        TextView close=text("Fermer",14,Color.LTGRAY,true);close.setGravity(Gravity.CENTER);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(44));cp.topMargin=dp(8);box.addView(close,cp);
        view.setOnClickListener(v->{ d.dismiss(); openPageDirectly(); }); diag.setOnClickListener(v->{ d.dismiss(); handler.post(this::runDiagnosticDialog); }); browser.setOnClickListener(v->{ d.dismiss(); openInBrowser(); }); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box);d.show();sizeDialog(d,88,WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void runDiagnosticDialog(){
        final Dialog d=dialog(); LinearLayout box=dialogBox();
        FrameLayout head=new FrameLayout(this);TextView title=text("Diagnostic",21,TEXT,true);head.addView(title,new FrameLayout.LayoutParams(-1,dp(42)));
        CopyIcon copy=new CopyIcon(this);FrameLayout.LayoutParams cpl=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.TOP);head.addView(copy,cpl);box.addView(head,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView state=text("Analyse en cours…",14,MUTED,false);box.addView(state,wrap());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout sections=new LinearLayout(this);sections.setOrientation(LinearLayout.VERTICAL);sections.setPadding(0,dp(12),0,0);scroll.addView(sections,new ScrollView.LayoutParams(-1,-2));box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        final String target=lastUrl;
        final String uaSnapshot=getUserAgent();
        final String webInfoSnapshot=getWebViewInfo();
        final String[] latestReport=new String[]{""};
        copy.setOnClickListener(v->{String report=latestReport[0]; if(report==null || report.length()==0){Toast.makeText(this,"Diagnostic encore en cours",Toast.LENGTH_SHORT).show();return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Diagnostic Movix",report));copy.setCopied(true);handler.postDelayed(()->copy.setCopied(false),900);});
        Button close=button("Fermer",false);LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,dp(48));cl.topMargin=dp(10);box.addView(close,cl);close.setOnClickListener(v->d.dismiss());
        d.setContentView(box);d.show();sizeDialog(d,94,Math.min((int)(getResources().getDisplayMetrics().heightPixels*0.84f), dp(700)));
        new Thread(()->{final String report=buildDiagnosticReport(target,uaSnapshot,webInfoSnapshot);runOnUiThread(()->{latestReport[0]=report;state.setText("Analyse terminée");sections.removeAllViews();addReportSections(sections,report);});}).start();
    }

    private void addReportSections(LinearLayout parent,String report){
        String[] parts=report.split("\\n\\n=== ");
        for(int i=0;i<parts.length;i++){
            String p=parts[i]; if(i>0)p="=== "+p;
            int nl=p.indexOf('\n');String heading=nl>0?p.substring(0,nl).replace("=== ",""):"Diagnostic";String body=nl>0?p.substring(nl+1):p;
            LinearLayout sec=new LinearLayout(this);sec.setOrientation(LinearLayout.VERTICAL);sec.setPadding(dp(14),dp(12),dp(14),dp(12));sec.setBackground(round(Color.rgb(12,12,12),Color.rgb(40,40,40),10));LinearLayout.LayoutParams sl=new LinearLayout.LayoutParams(-1,-2);sl.bottomMargin=dp(10);parent.addView(sec,sl);
            TextView h=text(heading,16,TEXT,true);sec.addView(h,wrap());TextView b=text(body,12,Color.rgb(218,214,205),false);b.setTextIsSelectable(true);b.setSingleLine(false);b.setHorizontallyScrolling(false);LinearLayout.LayoutParams bp=wrap();bp.topMargin=dp(8);sec.addView(b,bp);
        }
    }

    private String buildDiagnosticReport(String target,String ua,String webInfo){
        StringBuilder r=new StringBuilder();
        r.append("=== Diagnostic\n");
        r.append("Résultat général : ");
        boolean internet=hasInternet();
        ServerResult server=testServer(target);
        boolean vpnOn=MovixVpnState.isOn(this); String vpnMode=MovixVpnState.getMode(this), vpnScope=MovixVpnState.getScope(this), vpnErr=MovixVpnState.getLastError(this);
        if(vpnErr!=null && vpnErr.length()>0) r.append("PROBLÈME VPN DÉTECTÉ\n");
        else if(!internet) r.append("PROBLÈME RÉSEAU DÉTECTÉ\n");
        else if(!server.ok) r.append("PROBLÈME SERVEUR / CONNEXION DÉTECTÉ\n");
        else if(lastErrorType.equals("ssl")) r.append("PROBLÈME HTTPS / TLS PROBABLE\n");
        else r.append("SERVEUR ACCESSIBLE — COMPATIBILITÉ WEBVIEW À VÉRIFIER\n");
        r.append("\nÉtat des tests :\n");
        r.append(internet?"✓ Connexion réseau active\n":"✗ Aucune connexion réseau active\n");
        r.append(server.dnsOk?"✓ DNS fonctionnel\n":"✗ DNS en échec\n");
        r.append(server.ok?"✓ Serveur joignable\n":"✗ Serveur non joignable\n");
        r.append("• Dernier état de l'application : ").append(errorTypeLabel(lastErrorType)).append("\n");
        r.append("• WebView détecté : ").append(webInfo).append("\n");
        r.append("• Chromium dans l'User-Agent : ").append(extractChrome(ua)).append("\n");
        r.append("\nConclusion : ");
        if(!internet) r.append("la connexion de l'appareil est indisponible. Le WebView ne peut pas charger le site tant que le réseau n'est pas rétabli.\n");
        else if(!server.dnsOk) r.append("le nom de domaine ne peut pas être résolu depuis cet appareil ou ce réseau. Le problème est en amont du WebView.\n");
        else if(!server.ok) r.append("le test réseau n'obtient pas de réponse HTTP exploitable. Le problème peut venir du réseau, du serveur, d'un délai ou d'une négociation TLS incompatible.\n");
        else if(vpnErr!=null && vpnErr.length()>0) r.append("le VPN présente une erreur : ").append(vpnErr).append(". Le problème VPN doit être résolu avant de conclure que Movix ou le serveur est en cause.\n");
        else if("ssl".equals(lastErrorType)) r.append("le serveur est accessible mais la connexion sécurisée échoue dans Android/WebView. Une limitation TLS/certificat de l'ancien système est possible.\n");
        else if(vpnOn) r.append("le réseau, le serveur et le VPN sont accessibles. Le VPN est actif en mode ").append(vpnMode).append(" pour ").append(vpnScope).append(" ; aucun problème VPN n'est détecté.\n");
        else r.append("le serveur est accessible indépendamment du WebView, mais l'application a échoué à afficher la page. Le VPN est actuellement désactivé.\n");
        r.append("\n=== Appareil\n");
        r.append("Android : ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        r.append("Fabricant : ").append(Build.MANUFACTURER).append("\n");
        r.append("Modèle : ").append(Build.MODEL).append("\n");
        r.append("WebView : ").append(webInfo).append("\n");
        r.append("Chromium : ").append(extractChrome(ua)).append("\n");
        r.append("JavaScript : activé\nStockage local : activé\nCookies : activés\n");
        r.append("User-Agent : ").append(ua).append("\n");
        r.append("\n=== Application\n");
        r.append("Version : ").append(APP_VERSION).append("\n");
        r.append("URL testée : ").append(target).append("\n");
        r.append("Dernière erreur : ").append(errorTypeLabel(lastErrorType)).append("\n");
        r.append("Chargement principal : WebView intégré\n");
        r.append("Redirections HTTP/HTTPS : conservées dans l'application\n");
        r.append("\n=== Réseau\n");
        r.append("Connexion Android : ").append(internet?"OK":"ÉCHEC").append("\n");
        r.append("DNS : ").append(server.dnsOk?"OK":"ÉCHEC").append("\n");
        r.append("Temps serveur : ").append(server.timeMs>=0?server.timeMs+" ms":"non mesuré").append("\n");
        r.append("Code HTTP : ").append(server.code>0?String.valueOf(server.code):"non reçu").append("\n");
        r.append("URL finale : ").append(server.finalUrl==null?"non disponible":server.finalUrl).append("\n");
        r.append("Détail : ").append(server.detail).append("\n");
        r.append("\n=== VPN\n");
        r.append("État : ").append(vpnOn?"ACTIF":"INACTIF").append("\n");
        r.append("Mode : ").append(vpnMode).append("\n");
        r.append("Portée : ").append(vpnScope).append("\n");
        r.append("Dernière erreur VPN : ").append(vpnErr==null||vpnErr.length()==0?"aucune":vpnErr).append("\n");
        r.append("Fonction : VPN DNS léger vers 1.1.1.1").append("\n");
        return r.toString();
    }

    private ServerResult testServer(String target){
        ServerResult s=new ServerResult();
        try{URL u=new URL(target);long t=System.currentTimeMillis();InetAddress.getAllByName(u.getHost());s.dnsOk=true;s.dnsMs=System.currentTimeMillis()-t;}catch(Exception e){s.detail="DNS : "+e.getClass().getSimpleName()+" — "+msg(e);return s;}
        HttpURLConnection c=null;
        try{long t=System.currentTimeMillis();c=(HttpURLConnection)new URL(target).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setInstanceFollowRedirects(true);c.setRequestMethod("GET");c.setRequestProperty("User-Agent","MovixAndroid5-Diagnostic/2.0");c.connect();s.code=c.getResponseCode();s.timeMs=System.currentTimeMillis()-t;s.finalUrl=c.getURL().toString();s.ok=s.code>=200&&s.code<400;s.detail="Réponse HTTP "+s.code+" reçue en "+s.timeMs+" ms.";try{InputStream in=s.code>=400?c.getErrorStream():c.getInputStream();if(in!=null){byte[] b=new byte[512];in.read(b);in.close();}}catch(Exception ignored){}}
        catch(Exception e){s.detail=e.getClass().getSimpleName()+" — "+msg(e);}
        finally{if(c!=null)c.disconnect();}return s;
    }

    private String getWebViewInfo(){
        try{if(Build.VERSION.SDK_INT>=26){android.content.pm.PackageInfo p=WebView.getCurrentWebViewPackage();if(p!=null)return p.packageName+" "+p.versionName+" (code "+p.versionCode+")";}}catch(Exception ignored){}
        String[] pkgs={"com.google.android.webview","com.android.webview","com.google.android.webview.beta","com.google.android.webview.dev","com.google.android.webview.canary","com.android.chrome"};
        for(String pkg:pkgs){try{android.content.pm.PackageInfo p=getPackageManager().getPackageInfo(pkg,0);return p.packageName+" "+p.versionName+" (code "+p.versionCode+")";}catch(Exception ignored){}}
        return "Composant non identifié";
    }

    private String getUserAgent(){try{return webView.getSettings().getUserAgentString();}catch(Exception e){return "inconnu";}}
    private String extractChrome(String ua){if(ua==null)return "inconnu";Matcher m=Pattern.compile("(?:Chrome|CriOS)/([0-9.]+)").matcher(ua);return m.find()?m.group(1):"non détecté";}
    private String msg(Exception e){String m=e.getMessage();return TextUtils.isEmpty(m)?"aucun détail":m.replace('\n',' ').replace('\r',' ');}

    private Dialog dialog(){Dialog d=new Dialog(this);d.getWindow();d.requestWindowFeature(Window.FEATURE_NO_TITLE);d.setCancelable(true);return d;}
    private LinearLayout dialogBox(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(20),dp(22),dp(18));box.setBackground(round(CARD,Color.rgb(48,48,48),16));return box;}
    private void sizeDialog(Dialog d,int widthPercent,int height){Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);WindowManager.LayoutParams lp=new WindowManager.LayoutParams();lp.copyFrom(w.getAttributes());int screenW=getResources().getDisplayMetrics().widthPixels;lp.width=Math.max(dp(280),(int)(screenW*(widthPercent/100f)));lp.height=height;lp.gravity=Gravity.CENTER;lp.dimAmount=.72f;w.setAttributes(lp);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=0)g.setStroke(dp(1),stroke);return g;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(bold?Typeface.DEFAULT:Typeface.DEFAULT);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:TEXT);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);b.setBackground(round(primary?RED:Color.rgb(43,43,43),0,8));return b;}
    private LinearLayout.LayoutParams wrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private class ToggleSwitch extends View{
        private boolean checked;
        private float knob;
        private android.animation.ValueAnimator animator;
        private Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        ToggleSwitch(Context c){super(c);setClickable(true);knob=0f;}
        void setChecked(boolean value){checked=value;knob=value?1f:0f;invalidate();}
        @Override public boolean performClick(){super.performClick();return true;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float w=getWidth(),h=getHeight();float r=h/2f;paint.setStyle(Paint.Style.FILL);paint.setColor(checked?Color.rgb(80,35,35):Color.rgb(48,48,48));c.drawRoundRect(new RectF(0,0,w,h),r,r,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(Color.WHITE);c.drawRoundRect(new RectF(.5f,.5f,w-.5f,h-.5f),r,r,paint);
            float pad=dp(3), d=h-pad*2, x=pad+(w-d-pad*2)*knob;paint.setStyle(Paint.Style.FILL);paint.setColor(checked?RED:Color.rgb(170,170,170));c.drawCircle(x+d/2,h/2,d/2,paint);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==android.view.MotionEvent.ACTION_UP){if(animator!=null)animator.cancel();boolean next=!checked;float from=knob,to=next?1f:0f;checked=next;animator=android.animation.ValueAnimator.ofFloat(from,to);animator.setDuration(180);animator.addUpdateListener(a->{knob=(Float)a.getAnimatedValue();invalidate();});animator.start();performClick();return true;}return true;}
    }

    private class CopyIcon extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);RectF a=new RectF(),b=new RectF();boolean copied=false;CopyIcon(Context c){super(c);setContentDescription("Copier le diagnostic");setClickable(true);}
        void setCopied(boolean value){copied=value;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(dp(1.8f));p.setColor(TEXT);if(copied){PathLikeCheck(c);}else{float x=dp(10),y=dp(11),w=dp(13),h=dp(16);a.set(x+dp(4),y-dp(5),x+w+dp(4),y+h-dp(5));b.set(x,y,x+w,y+h);c.drawRoundRect(a,dp(2),dp(2),p);c.drawRoundRect(b,dp(2),dp(2),p);}}
        private void PathLikeCheck(Canvas c){android.graphics.Path q=new android.graphics.Path();q.moveTo(dp(9),dp(20));q.lineTo(dp(16),dp(27));q.lineTo(dp(31),dp(10));c.drawPath(q,p);}
        private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    }

    private static class ServerResult{boolean dnsOk,ok;int code;long timeMs=-1,dnsMs=-1;String finalUrl,detail="non mesuré";}


    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent); setIntent(intent);
        if(intent!=null && intent.getBooleanExtra("request_vpn",false)) handler.postDelayed(this::requestVpnFromActivity,150);
        if(intent!=null && intent.getBooleanExtra("open_hub",false)) handler.postDelayed(this::showAppHub,150);
    }

    @Override public void onBackPressed(){
        if(directPageMode && webView!=null && webView.getVisibility()==View.VISIBLE){
            directPageMode=false;
            try{webView.stopLoading();}catch(Exception ignored){}
            webView.setVisibility(View.GONE);
            loadingView.setVisibility(View.GONE);
            errorView.setVisibility(View.VISIBLE);
            return;
        }
        if(webView!=null && webView.getVisibility()==View.VISIBLE && webView.canGoBack()){webView.goBack();return;}
        if(errorView!=null && errorView.getVisibility()==View.VISIBLE){startLoad(lastUrl);return;}
        super.onBackPressed();
    }

    @Override protected void onDestroy(){loading=false;if(timeoutTask!=null)handler.removeCallbacks(timeoutTask);try{if(vpnReceiver!=null)unregisterReceiver(vpnReceiver);}catch(Exception ignored){}try{if(webView!=null){webView.stopLoading();webView.destroy();}}catch(Exception ignored){}super.onDestroy();}
}
