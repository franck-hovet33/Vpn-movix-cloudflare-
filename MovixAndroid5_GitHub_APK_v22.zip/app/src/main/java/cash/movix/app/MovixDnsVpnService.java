package cash.movix.app;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicBoolean;

/** Android 5 compatible, lightweight DNS VPN. It securely captures DNS traffic to 1.1.1.1. */
public class MovixDnsVpnService extends VpnService {
    public static final String ACTION_START="cash.movix.app.START_DNS_VPN";
    public static final String ACTION_STOP="cash.movix.app.STOP_DNS_VPN";
    private static final String DNS="1.1.1.1";
    private ParcelFileDescriptor vpnInterface;
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread worker;

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())) stopTunnel();
        else if(intent!=null && ACTION_START.equals(intent.getAction())) startTunnel();
        return START_STICKY;
    }

    private synchronized void startTunnel(){
        if(running.get()) return;
        String mode=MovixVpnState.getMode(this), scope=MovixVpnState.getScope(this);
        if(!"1.1.1.1".equals(mode)){
            MovixVpnState.recordError(this,"Le mode WARP n'est pas disponible dans cette version Android 5. Le mode 1.1.1.1 reste disponible.");
            stopSelf(); return;
        }
        try{
            Builder b=new Builder();
            b.setSession("Movix 1.1.1.1");
            b.addAddress("10.0.0.2",32);
            b.addRoute(DNS,32);
            b.addDnsServer(DNS);
            if("Movix uniquement".equals(scope)){
                try{ b.addAllowedApplication(getPackageName()); }
                catch(Exception e){ MovixVpnState.recordError(this,"Impossible de limiter le VPN à Movix : "+safe(e)); stopSelf(); return; }
            }
            vpnInterface=b.establish();
            if(vpnInterface==null) throw new IllegalStateException("Interface VPN indisponible");
            running.set(true);
            MovixVpnState.set(this,true,mode,scope,null);
            worker=new Thread(this::loop,"Movix-DNS-VPN"); worker.start();
        }catch(Throwable e){
            MovixVpnState.recordError(this,"Échec d'activation : "+safe(e));
            stopSelf();
        }
    }

    private void loop(){
        FileInputStream in=null; FileOutputStream out=null; DatagramSocket socket=null;
        byte[] packet=new byte[32767];
        try{
            in=new FileInputStream(vpnInterface.getFileDescriptor());
            out=new FileOutputStream(vpnInterface.getFileDescriptor());
            socket=new DatagramSocket(); protect(socket); socket.setSoTimeout(3000);
            while(running.get()){
                int n=in.read(packet); if(n<=0) continue;
                if(!isDnsRequest(packet,n)) continue;
                int ihl=(packet[0]&0x0F)*4, udp=ihl, payloadLen=n-udp-8;
                if(payloadLen<=0) continue;
                byte[] dns=new byte[payloadLen]; System.arraycopy(packet,udp+8,dns,0,payloadLen);
                int srcIp=readInt(packet,12), dstIp=readInt(packet,16);
                int srcPort=((packet[udp]&255)<<8)|(packet[udp+1]&255);
                DatagramPacket q=new DatagramPacket(dns,dns.length,InetAddress.getByName(DNS),53); socket.send(q);
                byte[] resp=new byte[4096]; DatagramPacket r=new DatagramPacket(resp,resp.length);
                try{socket.receive(r);}catch(java.net.SocketTimeoutException timeout){continue;}
                byte[] built=buildResponse(srcIp,dstIp,srcPort,r.getData(),r.getLength()); out.write(built); out.flush();
            }
        }catch(Throwable e){
            if(running.get()) MovixVpnState.recordError(this,"Tunnel arrêté : "+safe(e));
        }finally{
            try{if(socket!=null)socket.close();}catch(Exception ignored){}
            try{if(in!=null)in.close();}catch(Exception ignored){}
            try{if(out!=null)out.close();}catch(Exception ignored){}
            stopTunnel();
        }
    }

    private boolean isDnsRequest(byte[] p,int n){
        if(n<28)return false; int version=(p[0]>>4)&15, ihl=(p[0]&15)*4;
        if(version!=4||ihl<20||n<ihl+8||((p[9]&255)!=17))return false;
        if(readInt(p,16)!=ipv4(1,1,1,1))return false;
        int dp=((p[ihl+2]&255)<<8)|(p[ihl+3]&255); return dp==53;
    }
    private byte[] buildResponse(int originalSrc,int originalDst,int srcPort,byte[] dns,int dnsLen){
        int ipLen=20+8+dnsLen; byte[] p=new byte[ipLen]; p[0]=0x45; write16(p,2,ipLen);
        write16(p,4,(int)(System.nanoTime()&65535)); p[8]=64;p[9]=17;writeInt(p,12,originalDst);writeInt(p,16,originalSrc);
        write16(p,10,checksum(p,0,20)); int u=20;write16(p,u,53);write16(p,u+2,srcPort);write16(p,u+4,8+dnsLen);write16(p,u+6,0);
        System.arraycopy(dns,0,p,u+8,dnsLen); int sum=pseudoChecksum(p,12,16,17,8+dnsLen);write16(p,u+6,fold(sum));return p;
    }
    private int pseudoChecksum(byte[] p,int src,int dst,int proto,int udpLen){long s=0;s+=word(p,src)+word(p,src+2)+word(p,dst)+word(p,dst+2)+proto+udpLen;for(int i=20;i<p.length;i+=2)s+=((p[i]&255)<<8)|(i+1<p.length?(p[i+1]&255):0);while((s>>>16)!=0)s=(s&65535)+(s>>>16);return (int)s;}
    private int checksum(byte[] p,int off,int len){long s=0;for(int i=off;i<off+len;i+=2){if(i==off+10)continue;s+=word(p,i);}while((s>>>16)!=0)s=(s&65535)+(s>>>16);return (int)((~s)&65535);}
    private int word(byte[] p,int i){return ((p[i]&255)<<8)|(i+1<p.length?(p[i+1]&255):0);}
    private int fold(int s){long x=s&0xFFFFFFFFL;while((x>>>16)!=0)x=(x&65535)+(x>>>16);return (int)((~x)&65535);}
    private int readInt(byte[] p,int i){return ((p[i]&255)<<24)|((p[i+1]&255)<<16)|((p[i+2]&255)<<8)|(p[i+3]&255);}
    private void writeInt(byte[] p,int i,int v){p[i]=(byte)(v>>>24);p[i+1]=(byte)(v>>>16);p[i+2]=(byte)(v>>>8);p[i+3]=(byte)v;}
    private void write16(byte[] p,int i,int v){p[i]=(byte)(v>>>8);p[i+1]=(byte)v;}
    private int ipv4(int a,int b,int c,int d){return(a<<24)|(b<<16)|(c<<8)|d;}
    private String safe(Throwable e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():e.getClass().getSimpleName()+" — "+m;}
    private synchronized void stopTunnel(){
        boolean was=running.getAndSet(false); try{if(vpnInterface!=null)vpnInterface.close();}catch(Exception ignored){} vpnInterface=null;
        if(was) MovixVpnState.set(this,false,MovixVpnState.getMode(this),MovixVpnState.getScope(this),null); else MovixWidget.updateAll(this); stopSelf();
    }
    @Override public void onRevoke(){stopTunnel();super.onRevoke();}
    @Override public void onDestroy(){stopTunnel();super.onDestroy();}
}
