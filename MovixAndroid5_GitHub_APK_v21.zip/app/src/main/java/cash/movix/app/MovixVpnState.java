package cash.movix.app;

import android.content.Context;

public final class MovixVpnState {
    private static final String PREF = "vpn_state";
    private MovixVpnState() {}
    public static void set(Context c, boolean on) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply();
        VpnHistory.add(c, on ? "DNS Cloudflare activé" : "DNS Cloudflare désactivé");
        MovixWidget.updateAll(c);
    }
    public static boolean isOn(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("on", false); }
}
