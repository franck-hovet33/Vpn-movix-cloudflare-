package cash.movix.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;

public class MovixWidget extends AppWidgetProvider {
    private static final String TOGGLE="cash.movix.app.WIDGET_TOGGLE";
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
    @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(TOGGLE.equals(i.getAction())){toggle(c);}}
    private void toggle(Context c){
        if(MovixVpnState.isOn(c)){
            c.stopService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_STOP));
        }else{
            Intent prep=android.net.VpnService.prepare(c);
            if(prep!=null){
                Intent open=new Intent(c,MainActivity.class).putExtra("request_vpn",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                c.startActivity(open);
            }else c.startService(new Intent(c,MovixDnsVpnService.class).setAction(MovixDnsVpnService.ACTION_START));
        }
        updateAll(c);
    }
    static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new android.content.ComponentName(c,MovixWidget.class));for(int id:ids)update(c,m,id);}
    private static void update(Context c,AppWidgetManager m,int id){
        boolean on=MovixVpnState.isOn(c);RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_movix);
        v.setTextViewText(R.id.widget_status,on?"ON":"OFF");v.setTextViewText(R.id.widget_sub,on?"Cloudflare DNS":"DNS normal");
        v.setTextColor(R.id.widget_status,on?Color.rgb(110,220,130):Color.rgb(245,240,223));
        Intent t=new Intent(c,MovixWidget.class).setAction(TOGGLE);PendingIntent p=PendingIntent.getBroadcast(c,0,t,PendingIntent.FLAG_UPDATE_CURRENT);v.setOnClickPendingIntent(R.id.widget_button,p);m.updateAppWidget(id,v);
    }
}
