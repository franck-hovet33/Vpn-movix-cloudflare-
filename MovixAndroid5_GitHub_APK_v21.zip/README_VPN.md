# Movix 2.6 — mode réseau léger

Cette version ajoute un **mode DNS Cloudflare léger** compatible Android 5 via `VpnService`, un widget d'écran d'accueil 2×2 et un historique local.

## Important

Le tunnel n'est pas une implémentation de WARP. Il intercepte les requêtes DNS IPv4 destinées à `1.1.1.1:53` et les relaie vers Cloudflare. Le trafic HTTP/HTTPS reste sur le chemin réseau normal.

Il peut donc aider lorsque le blocage du site est **uniquement basé sur le DNS**. Il ne contourne pas un filtrage IP, SNI, HTTP ou un blocage du réseau lui-même.

## Widget

Le widget est prévu pour une taille minimale 2×2 et permet d'activer/désactiver le mode DNS. Au premier démarrage, Android demande l'autorisation VPN.

## Historique

L'application conserve localement les 30 derniers changements d'état du mode DNS.

## Android

`minSdk 21` (Android 5.0+). Aucun certificat ou vérification TLS n'est contourné.
