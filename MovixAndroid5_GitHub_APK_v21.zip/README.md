# Movix Android 5 v18

Version 2.4 — versionCode 15.

Fonctions principales : WebView Android 5, écran de chargement, écran d'erreur, menu ⋮, diagnostic détaillé, copie du rapport, historique d'URL en fenêtre flottante au-dessus du champ, consultation WebView indépendante avec retour vers l'écran d'erreur, et ouverture de l'URL dans le navigateur système.

Le projet est destiné à être compilé par GitHub Actions avec le workflow fourni.
