package cash.movix.app;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Lightweight Android 5 compatible DNS-only VPN.
 * It captures traffic destined to 1.1.1.1:53 and forwards the DNS payload
 * to Cloudflare through a protected UDP socket. Normal application traffic
 * remains on the normal network path.
 */
public class MovixDnsVpnService extends VpnService {
    public static final String ACTION_START = "cash.movix.app.START_DNS_VPN";
    public static final String ACTION_STOP = "cash.movix.app.STOP_DNS_VPN";
    private static final String DNS = "1.1.1.1";
    private ParcelFileDescriptor vpnInterface;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread worker;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) stopTunnel();
        else if (intent != null && ACTION_START.equals(intent.getAction())) startTunnel();
        return START_STICKY;
    }

    private synchronized void startTunnel() {
        if (running.get()) return;
        try {
            Builder b = new Builder();
            b.setSession("Movix DNS");
            b.addAddress("10.0.0.2", 32);
            b.addRoute(DNS, 32);
            if (android.os.Build.VERSION.SDK_INT >= 21) b.addDnsServer(DNS);
            vpnInterface = b.establish();
            if (vpnInterface == null) throw new IllegalStateException("VPN interface unavailable");
            running.set(true);
            MovixVpnState.set(this, true);
            worker = new Thread(this::loop, "Movix-DNS-VPN");
            worker.start();
        } catch (Throwable e) {
            MovixVpnState.set(this, false);
            stopSelf();
        }
    }

    private void loop() {
        FileInputStream in = null;
        FileOutputStream out = null;
        DatagramSocket socket = null;
        byte[] packet = new byte[32767];
        try {
            in = new FileInputStream(vpnInterface.getFileDescriptor());
            out = new FileOutputStream(vpnInterface.getFileDescriptor());
            socket = new DatagramSocket();
            protect(socket);
            socket.setSoTimeout(3000);
            while (running.get()) {
                int n = in.read(packet);
                if (n <= 0) continue;
                if (!isDnsRequest(packet, n)) continue;
                int ihl = (packet[0] & 0x0F) * 4;
                int udp = ihl;
                int payloadLen = n - udp - 8;
                if (payloadLen <= 0) continue;
                byte[] dns = new byte[payloadLen];
                System.arraycopy(packet, udp + 8, dns, 0, payloadLen);
                int srcIp = readInt(packet, 12);
                int dstIp = readInt(packet, 16);
                int srcPort = ((packet[udp] & 0xFF) << 8) | (packet[udp + 1] & 0xFF);
                DatagramPacket q = new DatagramPacket(dns, dns.length, InetAddress.getByName(DNS), 53);
                socket.send(q);
                byte[] resp = new byte[4096];
                DatagramPacket r = new DatagramPacket(resp, resp.length);
                try { socket.receive(r); } catch (java.net.SocketTimeoutException timeout) { continue; }
                byte[] built = buildResponse(srcIp, dstIp, srcPort, r.getData(), r.getLength());
                out.write(built);
                out.flush();
            }
        } catch (Throwable ignored) {
        } finally {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
            stopTunnel();
        }
    }

    private boolean isDnsRequest(byte[] p, int n) {
        if (n < 28) return false;
        int version = (p[0] >> 4) & 0xF;
        int ihl = (p[0] & 0xF) * 4;
        if (version != 4 || ihl < 20 || n < ihl + 8) return false;
        if ((p[9] & 0xFF) != 17) return false;
        int dst = readInt(p, 16);
        if (dst != ipv4(1,1,1,1)) return false;
        int dp = ((p[ihl+2]&0xFF)<<8)|(p[ihl+3]&0xFF);
        return dp == 53;
    }

    private byte[] buildResponse(int originalSrc, int originalDst, int srcPort, byte[] dns, int dnsLen) {
        int ipLen = 20 + 8 + dnsLen;
        byte[] p = new byte[ipLen];
        p[0] = 0x45;
        p[1] = 0;
        write16(p,2,ipLen);
        write16(p,4,(int)(System.nanoTime() & 0xFFFF));
        write16(p,6,0);
        p[8] = 64;
        p[9] = 17;
        writeInt(p,12,originalDst);
        writeInt(p,16,originalSrc);
        write16(p,10,checksum(p,0,20));
        int u = 20;
        write16(p,u,53);
        write16(p,u+2,srcPort);
        write16(p,u+4,8+dnsLen);
        write16(p,u+6,0);
        System.arraycopy(dns,0,p,u+8,dnsLen);
        int sum = pseudoChecksum(p,12,16,17,8+dnsLen);
        write16(p,u+6,fold(sum));
        return p;
    }

    private int pseudoChecksum(byte[] p,int src,int dst,int proto,int udpLen){
        long s=0;
        s += word(p,src)+word(p,src+2)+word(p,dst)+word(p,dst+2)+proto+udpLen;
        for(int i=20;i<p.length;i+=2) s += ((p[i]&255)<<8) | (i+1<p.length?(p[i+1]&255):0);
        while((s>>>16)!=0)s=(s&0xFFFF)+(s>>>16);
        return (int)s;
    }
    private int checksum(byte[] p,int off,int len){
        long s=0; for(int i=off;i<off+len;i+=2){ if(i==off+10) continue; s+=word(p,i); }
        while((s>>>16)!=0)s=(s&0xFFFF)+(s>>>16); return (~s)&0xFFFF;
    }
    private int word(byte[] p,int i){return ((p[i]&255)<<8)|(i+1<p.length?(p[i+1]&255):0);}
    private int fold(int s){while((s>>>16)!=0)s=(s&0xFFFF)+(s>>>16);return (~s)&0xFFFF;}
    private int readInt(byte[] p,int i){return ((p[i]&255)<<24)|((p[i+1]&255)<<16)|((p[i+2]&255)<<8)|(p[i+3]&255);}
    private void writeInt(byte[] p,int i,int v){p[i]=(byte)(v>>>24);p[i+1]=(byte)(v>>>16);p[i+2]=(byte)(v>>>8);p[i+3]=(byte)v;}
    private void write16(byte[] p,int i,int v){p[i]=(byte)(v>>>8);p[i+1]=(byte)v;}
    private int ipv4(int a,int b,int c,int d){return (a<<24)|(b<<16)|(c<<8)|d;}

    private synchronized void stopTunnel() {
        if (!running.getAndSet(false)) { MovixVpnState.set(this, false); stopSelf(); return; }
        try { if (vpnInterface != null) vpnInterface.close(); } catch (Exception ignored) {}
        vpnInterface = null;
        MovixVpnState.set(this, false);
        stopSelf();
    }

    @Override public void onRevoke() { stopTunnel(); super.onRevoke(); }
    @Override public void onDestroy() { stopTunnel(); super.onDestroy(); }
}
